from django.apps import AppConfig


class SamuelamujoConfig(AppConfig):
    name = 'samuelamujo'
